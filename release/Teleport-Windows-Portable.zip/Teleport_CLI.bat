@echo off
title Teleport CLI
cd /d "%~dp0"
:menu
cls
echo.
echo ========================================
echo   Teleport CLI
echo ========================================
echo.
echo   1. Discover devices
echo   2. Receive files
echo   3. Send files
echo   4. Help
echo   5. Command prompt
echo   6. Exit
echo.
set /p c="Select: "
if "%c%"=="1" (teleport_cli.exe discover & pause & goto menu)
if "%c%"=="2" (teleport_cli.exe receive & pause & goto menu)
if "%c%"=="3" (teleport_cli.exe discover --timeout 5 & set /p t="Target: " & set /p f="Files: " & teleport_cli.exe send %f% --to %t% & pause & goto menu)
if "%c%"=="4" (teleport_cli.exe --help & pause & goto menu)
if "%c%"=="5" (cmd /k & goto menu)
if "%c%"=="6" exit
goto menu
